select [StaffID],[Pic],[PicType]
into DataPicker_StaffPic
from [dbo].[vwStaffMaster]